﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelTest
{
    public class modelList
    {
        public string modal_name;

        public int id;


    }
}
