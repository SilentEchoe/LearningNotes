﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelTest
{
    public class model
    {
        public string oldModel { get; set; }

        //public string Value1 { get; set; }

        //public string Value2 { get; set; }

        public string newModel { get; set; }



    }

    public class model2
    {
        public string Modelname { get; set; }

        public string Value1 { get; set; }

        public string Value2 { get; set; }

        public string Value3 { get; set; }
        public string Value4 { get; set; }
        public string Value5 { get; set; }
        public string Value6 { get; set; }

        public string Base64 { get; set; }

        public string Sum { get; set; }

    }

}
